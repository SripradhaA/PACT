package io.pivotal.microservices.pact.consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import io.pivotal.microservices.pact.consumer.Foo;

import java.net.URI;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

@Component
public class ConsumerPort {

    private String url;
    private RestTemplate restTemplate;
  
    @Autowired
    public ConsumerPort(@Value("${producer}") String url) {
        this.url = url;
        System.out.println("******************************Printing this url ::: "+url);
        this.restTemplate = new RestTemplate();
    }

    /*public Foo fetchDetails(URI productDetailsUri) {
    	//URI productDetailsUri = URI.create( "http://localhost:8089/insert");
    	Foo foo = new Foo();
    	foo.setZz(new RestTemplate().getForObject(productDetailsUri,String.class));
	    return foo;
	  }*/
    public String foos() {
    	Foo foo = new Foo();
        ParameterizedTypeReference<String> responseType = new ParameterizedTypeReference<String>() {};

        //String rest =restTemplate.exchange(url + "/insert", HttpMethod.GET, null, responseType).getBody();
        //System.out.println("rest");
        //foo.setZz(rest);
        
        
       
        System.out.println("************responseType------------"+  responseType);      
		return restTemplate.exchange(url + "/insert", HttpMethod.GET, null, responseType).getBody();
       //return rest;
		
    }
}
