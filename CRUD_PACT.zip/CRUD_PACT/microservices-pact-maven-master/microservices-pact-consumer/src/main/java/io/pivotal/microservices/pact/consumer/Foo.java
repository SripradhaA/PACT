package io.pivotal.microservices.pact.consumer;

public class Foo {

    //private int value;
    private String zz;
    
    
	@Override
	public String toString() {
		/*return "Foo [zz=" + zz + ", hashCode()=" + hashCode() + ", getZz()="
				+ getZz() + "]";*/
    	return zz;
	}
	public Foo() {
    }
	 public Foo(String zz) {
	        this.zz = zz;
	    }
	 public String getZz() {
			return zz;
		}
	 public void setZz(String zz) {
			this.zz = zz;
		}
	/*@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((zz == null) ? 0 : zz.hashCode());
		return result;
	}*/
	/*@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Foo other = (Foo) obj;
		if (zz == null) {
			if (other.zz != null)
				return false;
		} else if (!zz.equals(other.zz))
			return false;
		return true;
	}*/
	

	/*@Override
	public String toString() {
		return zz;
	}*/

	
	/*@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + value;
		result = prime * result + ((zz == null) ? 0 : zz.hashCode());
		return result;
	}*/

	/*@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null || getClass() != obj.getClass()) return false;
		
			
		
		Foo foo = (Foo) obj;
		if (zz != foo.zz) return false;
		
		return true;
	}
*/
	

	

    /*public Foo(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }*/

    
}
