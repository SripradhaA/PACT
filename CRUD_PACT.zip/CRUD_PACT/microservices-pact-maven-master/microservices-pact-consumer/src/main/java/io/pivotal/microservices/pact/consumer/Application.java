package io.pivotal.microservices.pact.consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

@Configuration
@ComponentScan
@EnableAutoConfiguration
@RestController
public class Application {

	@Autowired
	 ConsumerPort consumerPort ;

    @RequestMapping(value="/foos", method = RequestMethod.GET,produces="text/plain;charset=ISO-8859-1")
    public String foos() {
    	
    return consumerPort.foos();
    }	
    	/*URI productDetailsUri = URI.create( "http://localhost:8089/insert");
    	Foo foo = new Foo();
    	//return new Foo("Insert Service Invoked............");
    	//return foo;
    	System.out.println("consumerPort.fetchDetails(productDetailsUri)= "+ consumerPort.fetchDetails(productDetailsUri));

    	return consumerPort.fetchDetails(productDetailsUri);*/
        
    

    @RequestMapping("/")
    public String hello() {
        return "Hello World!";
    }

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
