package io.pivotal.microservices.pact.consumer;

import au.com.dius.pact.consumer.*;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.PactFragment;

import org.junit.Rule;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static junit.framework.TestCase.assertEquals;

public class ConsumerPortTest {
	@Autowired
	ConsumerPort c;
    @Rule
    public PactProviderRule rule = new PactProviderRule("Foo_Provider",this);

    @Pact(provider="Foo_Provider", consumer="Foo_Consumer")
    public PactFragment createFragment(PactDslWithProvider builder) { 
       /*String url="http://localhost:8089/insert";
       URI productDetailsUri = URI.create(url);*/
       Map<String, String> headers = new HashMap<>();
       headers.put("Content-Type", "text/plain;charset=ISO-8859-1");

       /*ConsumerPort productDetailsFetcher = new ConsumerPort();
       productDetailsFetcher.fetchDetails(productDetailsUri);*/
      // headers.put("Content-Type", "text/html;charset=ISO-8859-1");
        return builder.uponReceiving("a request")
                .path("/insert")
                .method("GET")              
                .willRespondWith()
                .headers(headers)
                .status(200)
              //.body("{\"zz\":\"Insert Service Invoked............\"}")
                .body("Insert Service Invoked............")
                .toFragment();    
}
    
    /*protected String providerName() {
      return "Product_Details_Service";
    }
   
    protected String consumerName() {
      return "Product_Service";
    }*/
    /*@Test
    @PactVerification(value="Foo_Provider",fragment = "createFragment")
   
    public void runTest() {
    	Foo foo = new Foo();
      String url="http://localhost:8089/insert";
      URI productDetailsUri = URI.create(url);//(String.format( url, "/insert"));
      ConsumerPort productDetailsFetcher = new ConsumerPort();
      
      System.out.println("value productDetailsFetcher.fetchDetails(productDetailsUri) = "+productDetailsFetcher.fetchDetails(productDetailsUri));
      System.out.println("value new Foo(Insert Service Invoked............)= "+ new Foo("Insert Service Invoked............"));
     // String productDetails = productDetailsFetcher.fetchDetails(productDetailsUri);
      assertEquals(productDetailsFetcher.fetchDetails(productDetailsUri),new Foo("Insert Service Invoked............"));
    }*/

    @Test
  @PactVerification("Foo_Provider")
    public void runTest() {
try{	
	//Foo foo = new Foo();	
	assertEquals(new ConsumerPort(rule.getConfig().url()).foos().toString(), new Foo("Insert Service Invoked............").toString());
	}
catch(Exception e)
    {
   System.out.println("**********Expected**********" +"  "+ new ConsumerPort(rule.getConfig().url()).foos()+ "   " +"Actual"+"   "+new Foo("Insert Service Invoked............")+ " Exception is " +e);
    }
	
    }
}
